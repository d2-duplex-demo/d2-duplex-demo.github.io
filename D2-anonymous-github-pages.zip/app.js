/* Local interactions only. No analytics, remote services, or microphone access. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const examples = window.D2_EXAMPLES.examples;
  const audio = $('demo-player');
  const ns = 'http://www.w3.org/2000/svg';
  const formatTime = (seconds) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
  const svgNode = (tag, attributes = {}, text) => {
    const node = document.createElementNS(ns, tag);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, value));
    if (text !== undefined) node.textContent = text;
    return node;
  };

  examples.forEach((example, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'example-choice';
    button.dataset.example = example.id;
    button.setAttribute('aria-controls', 'example-title demo-player');
    button.setAttribute('aria-pressed', String(index === 0));
    const number = document.createElement('span');
    number.className = 'example-number';
    number.textContent = String(index + 1).padStart(2, '0');
    const content = document.createElement('span');
    const label = document.createElement('strong');
    label.textContent = example.label;
    const model = document.createElement('small');
    model.textContent = `${example.model} · ${example.chunkMs} ms`;
    const duration = document.createElement('span');
    duration.className = 'example-time';
    duration.textContent = `▷  ${formatTime(example.duration)}`;
    content.append(label, model, duration);
    button.append(number, content);
    button.addEventListener('click', () => selectExample(example));
    $('example-list').append(button);
  });

  function selectExample(example) {
    audio.pause();
    audio.src = example.video;
    audio.poster = example.poster;
    audio.setAttribute('aria-label', `Recorded conversation: ${example.title}`);
    audio.load();
    $('example-model').textContent = example.model;
    $('example-chunk').textContent = `${example.chunkMs} ms chunks`;
    $('example-title').textContent = example.title;
    $('example-description').textContent = example.description;
    $('example-source').textContent = example.source;
    $('clip-duration').textContent = formatTime(example.duration);
    $('download-audio').href = example.src;
    $('download-video').href = example.video;
    $('audio-status').textContent = '';
    document.querySelectorAll('[data-example]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.example === example.id)));
    $('transcript-note').textContent = example.transcriptNote;
    const transcript = $('transcript-content');
    transcript.replaceChildren();
    example.turns.forEach((turn) => {
      const block = document.createElement('div');
      block.className = `transcript-turn${turn.role.startsWith('User') ? ' user' : ''}`;
      const role = document.createElement('h4');
      role.textContent = turn.role;
      const text = document.createElement('p');
      text.textContent = turn.text;
      block.append(role, text);
      transcript.append(block);
    });
  }
  audio.addEventListener('error', () => {
    $('audio-status').textContent = 'The video could not be loaded. Try the MP4 or WAV download below.';
  });
  selectExample(examples[0]);

  // Values transcribed from manuscript Tables 1–2. Latencies retain paper rounding.
  const families = {
    qwen: { name: 'Qwen3-Omni-D2', backbone: 86.8, rows: [
      { chunk: 80, score: 70.1, latency: 521, pause: 21.3 },
      { chunk: 160, score: 67.8, latency: 539, pause: 19.0 },
      { chunk: 320, score: 71.6, latency: 710, pause: 25.5 },
      { chunk: 640, score: 71.3, latency: 1010, pause: 55.1 },
      { chunk: 1040, score: 73.0, latency: 1380, pause: 61.6 },
    ] },
    llama: { name: 'LLaMA-Omni 2-D2', backbone: 48.5, rows: [
      { chunk: 100, score: 34.7, latency: 746, pause: 74.5 },
      { chunk: 200, score: 38.1, latency: 825, pause: 78.2 },
      { chunk: 400, score: 41.1, latency: 1020, pause: 69.4 },
      { chunk: 800, score: 42.0, latency: 1450, pause: 70.8 },
    ] },
  };
  let family = families.qwen;
  let rowIndex = 0;

  function drawChart() {
    const svg = $('results-chart');
    svg.replaceChildren();
    const row = family.rows[rowIndex];
    const x = (chunk) => 45 + chunk / 1100 * 470;
    const y = (score) => 215 - score * 1.8;
    svg.append(svgNode('title', { id: 'chart-title' }, `${family.name}: VoiceBench by chunk duration`));
    svg.append(svgNode('desc', { id: 'chart-description' }, `${family.rows.map((r) => `${r.chunk} ms: ${r.score}`).join('; ')}. Original half-duplex backbone: ${family.backbone}. Selected: ${row.chunk} ms.`));
    svg.append(svgNode('text', { x: 45, y: 15, fill: '#63706b', 'font-size': 10 }, 'VoiceBench score ↑'));
    [0, 25, 50, 75, 100].forEach((score) => {
      svg.append(svgNode('line', { x1: 45, x2: 520, y1: y(score), y2: y(score), stroke: '#e7ebe4', 'stroke-width': 1 }));
      svg.append(svgNode('text', { x: 34, y: y(score) + 3, 'text-anchor': 'end', fill: '#7a8780', 'font-size': 9 }, String(score)));
    });
    [0, 200, 400, 600, 800, 1000].forEach((chunk) => {
      svg.append(svgNode('text', { x: x(chunk), y: 234, 'text-anchor': 'middle', fill: '#7a8780', 'font-size': 9 }, chunk.toLocaleString('en-US')));
    });
    svg.append(svgNode('text', { x: 520, y: 257, 'text-anchor': 'end', fill: '#63706b', 'font-size': 10 }, 'Chunk duration (ms)'));
    svg.append(svgNode('line', { x1: 45, x2: 520, y1: y(family.backbone), y2: y(family.backbone), stroke: '#9aaa9f', 'stroke-width': 1.5, 'stroke-dasharray': '5 5' }));
    svg.append(svgNode('text', { x: 515, y: y(family.backbone) - 8, 'text-anchor': 'end', fill: '#728579', 'font-size': 10 }, `HD backbone · ${family.backbone}`));
    svg.append(svgNode('polyline', { points: family.rows.map((r) => `${x(r.chunk)},${y(r.score)}`).join(' '), fill: 'none', stroke: '#146e5d', 'stroke-width': 2.3, 'stroke-linejoin': 'round' }));
    family.rows.forEach((r, i) => {
      if (i === rowIndex) svg.append(svgNode('circle', { cx: x(r.chunk), cy: y(r.score), r: 10, fill: '#dfede3' }));
      svg.append(svgNode('circle', { cx: x(r.chunk), cy: y(r.score), r: i === rowIndex ? 5 : 3.5, fill: '#146e5d', stroke: '#fff', 'stroke-width': 1.5 }));
    });
    svg.append(svgNode('text', { x: x(row.chunk), y: y(row.score) + 25, 'text-anchor': 'middle', fill: '#146e5d', 'font-size': 12, 'font-weight': 600 }, row.score.toFixed(1)));
  }

  function renderResults() {
    const row = family.rows[rowIndex];
    const controls = $('chunk-options');
    controls.replaceChildren();
    family.rows.forEach((r, i) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = `${r.chunk.toLocaleString('en-US')} ms`;
      button.setAttribute('aria-pressed', String(i === rowIndex));
      button.addEventListener('click', () => {
        rowIndex = i;
        // Update in place to retain keyboard focus.
        controls.querySelectorAll('button').forEach((b, j) => b.setAttribute('aria-pressed', String(j === i)));
        renderSelection();
      });
      controls.append(button);
    });
    renderSelection();
  }
  function renderSelection() {
    const row = family.rows[rowIndex];
    const container = $('selected-results');
    container.replaceChildren();
    [['VoiceBench score', row.score.toFixed(1), '/ 100'], ['Turn-taking latency', row.latency.toLocaleString('en-US'), 'ms'], ['Pause-handling success', row.pause.toFixed(1), '%']].forEach(([label, value, unit]) => {
      const dl = document.createElement('dl');
      dl.className = 'selected-result';
      const dt = document.createElement('dt'); dt.textContent = label;
      const dd = document.createElement('dd'); dd.textContent = value;
      const suffix = document.createElement('span'); suffix.textContent = unit;
      dd.append(suffix); dl.append(dt, dd); container.append(dl);
    });
    $('tradeoff-note').textContent = `At ${row.chunk.toLocaleString('en-US')} ms, ${family.name} scores ${row.score.toFixed(1)} on VoiceBench, with ${row.latency.toLocaleString('en-US')} ms turn-taking latency and ${row.pause.toFixed(1)}% pause-handling success.`;
    drawChart();
  }
  $('backbone').addEventListener('change', (event) => {
    family = families[event.target.value]; rowIndex = 0; renderResults();
  });
  renderResults();
})();
