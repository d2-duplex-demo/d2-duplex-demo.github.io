/* Local interactions only. No analytics, remote services, or microphone access. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const examples = window.D2_EXAMPLES.examples;
  const audio = $('demo-player');
  const ns = 'http://www.w3.org/2000/svg';
  const formatTime = (seconds) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
  const svgNode = (tag, attributes = {}, text) => {
    const node = document.createElementNS(ns, tag);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, value));
    if (text !== undefined) node.textContent = text;
    return node;
  };

  examples.forEach((example, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'example-choice';
    button.dataset.example = example.id;
    button.setAttribute('aria-controls', 'example-title demo-player');
    button.setAttribute('aria-pressed', String(index === 0));
    const number = document.createElement('span');
    number.className = 'example-number';
    number.textContent = String(index + 1).padStart(2, '0');
    const content = document.createElement('span');
    const label = document.createElement('strong');
    label.textContent = example.label;
    const model = document.createElement('small');
    model.textContent = `${example.model} · ${example.chunkMs} ms`;
    const duration = document.createElement('span');
    duration.className = 'example-time';
    duration.textContent = `▷  ${formatTime(example.duration)}`;
    content.append(label, model, duration);
    button.append(number, content);
    button.addEventListener('click', () => selectExample(example));
    $('example-list').append(button);
  });

  function selectExample(example) {
    audio.pause();
    audio.src = example.video;
    audio.poster = example.poster;
    audio.setAttribute('aria-label', `Recorded conversation: ${example.title}`);
    audio.load();
    $('example-model').textContent = example.model;
    $('example-chunk').textContent = `${example.chunkMs} ms chunks`;
    $('example-title').textContent = example.title;
    $('example-description').textContent = example.description;
    $('example-source').textContent = example.source;
    $('clip-duration').textContent = formatTime(example.duration);
    $('download-audio').href = example.src;
    $('download-video').href = example.video;
    $('audio-status').textContent = '';
    document.querySelectorAll('[data-example]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.example === example.id)));
    $('transcript-note').textContent = example.transcriptNote;
    const transcript = $('transcript-content');
    transcript.replaceChildren();
    example.turns.forEach((turn) => {
      const block = document.createElement('div');
      block.className = `transcript-turn${turn.role.startsWith('User') ? ' user' : ''}`;
      const role = document.createElement('h4');
      role.textContent = turn.role;
      const text = document.createElement('p');
      text.textContent = turn.text;
      block.append(role, text);
      transcript.append(block);
    });
  }
  audio.addEventListener('error', () => {
    $('audio-status').textContent = 'The video could not be loaded. Try the MP4 or WAV download below.';
  });
  selectExample(examples[0]);

  // Values transcribed from manuscript Tables 1–2. Latencies retain paper rounding.
  const families = {
    qwen: { name: 'Qwen3-Omni-D2', color: '#2861d7', shape: 'circle', backbone: 86.8, rows: [
      { chunk: 80, score: 70.1, latency: 521, tt: 99.2, interrupt: 99.5, intLatency: 403, pause: 21.3 },
      { chunk: 160, score: 67.8, latency: 539, tt: 100, interrupt: 99.5, intLatency: 432, pause: 19.0 },
      { chunk: 320, score: 71.6, latency: 710, tt: 100, interrupt: 99.5, intLatency: 571, pause: 25.5 },
      { chunk: 640, score: 71.3, latency: 1010, tt: 99.2, interrupt: 99.5, intLatency: 928, pause: 55.1 },
      { chunk: 1040, score: 73.0, latency: 1380, tt: 100, interrupt: 99.5, intLatency: 1300, pause: 61.6 },
    ] },
    llama: { name: 'LLaMA-Omni 2-D2', color: '#8250cc', shape: 'square', backbone: 48.5, rows: [
      { chunk: 100, score: 34.7, latency: 746, tt: 100, interrupt: 99.5, intLatency: 621, pause: 74.5 },
      { chunk: 200, score: 38.1, latency: 825, tt: 99.2, interrupt: 100, intLatency: 710, pause: 78.2 },
      { chunk: 400, score: 41.1, latency: 1020, tt: 100, interrupt: 99.0, intLatency: 894, pause: 69.4 },
      { chunk: 800, score: 42.0, latency: 1450, tt: 98.3, interrupt: 99.0, intLatency: 1320, pause: 70.8 },
    ] },
  };
  let family = families.qwen;
  let rowIndex = 0;
  let chartAxis = 'fd';
  // Scores/TORs/latencies: manuscript Tables 1–2. Baseline chunk sizes:
  // author's supplied chunk-size landscape. HD models have no FD-Score.
  const baselines = [
    { name: 'Nemotron VoiceChat', chunk: 80, score: 53.3, tt: 91.6, latency: 584, interrupt: 99, intLatency: 638, color: '#20834c', chunkLabel: [135, 220], fdLabel: [606, 232] },
    { name: 'Freeze-Omni', chunk: 160, score: 53.2, tt: 34.5, latency: 288, interrupt: 98.5, intLatency: 349, color: '#0084a5', chunkLabel: [181, 265], fdLabel: [465, 281] },
    { name: 'MiniCPM-o 4.5', chunk: 1000, score: 61.0, tt: 75.6, latency: 1920, interrupt: 94.5, intLatency: 1890, color: '#b95d08', chunkLabel: [529, 198], fdLabel: [255, 195] },
    { name: 'BayLing-Duplex', chunk: 800, score: 32.4, tt: 85.7, latency: 5570, interrupt: 100, intLatency: 5190, color: '#c34848', chunkLabel: [491, 381], fdLabel: [128, 354] },
    { name: 'PersonaPlex', chunk: 80, score: 32.7, tt: 99.2, latency: 346, interrupt: 95, intLatency: 294, color: '#b54085', chunkLabel: [197, 344], fdLabel: [700, 337] },
    { name: 'Moshi', chunk: 80, score: 30.0, tt: 100, latency: 615, interrupt: 89.5, intLatency: 1230, color: '#977100', chunkLabel: [197, 377], fdLabel: [476, 385] },
  ];
  const hdModels = [
    { name: 'Qwen3-Omni', score: 86.8, color: '#2861d7', shape: 'circle' },
    { name: 'Kimi-Audio', score: 72.3, color: '#008b80', shape: 'diamond' },
    { name: 'LLaMA-Omni 2', score: 48.5, color: '#8250cc', shape: 'square' },
  ];
  const fdScore = (r) => (r.tt / (1 + r.latency / 1000) + r.interrupt / (1 + r.intLatency / 1000)) / 2;

  function drawChart() {
    const svg = $('results-chart');
    svg.replaceChildren();
    const row = family.rows[rowIndex];
    const isChunk = chartAxis === 'chunk';
    const x = (r) => isChunk ? 62 + r.chunk / 1100 * 638 : 62 + (fdScore(r) - 10) / 70 * 702;
    const y = (score) => 400 - (score - 25) / 70 * 350;
    const label = (text, px, py, color = '#63706b', extra = {}) => svgNode('text', { x: px, y: py, fill: color, 'font-size': 14, ...extra }, text);
    const marker = (px, py, shape, color, open = false, selected = false) => {
      const g = svgNode('g', {});
      if (selected) g.append(svgNode('circle', { cx: px, cy: py, r: 13, fill: color, opacity: .16 }));
      const attrs = { fill: open ? '#fff' : color, stroke: open ? color : '#fff', 'stroke-width': open ? 2.5 : 1.7 };
      if (shape === 'square') g.append(svgNode('rect', { x: px - 5.5, y: py - 5.5, width: 11, height: 11, ...attrs }));
      else if (shape === 'diamond') g.append(svgNode('path', { d: `M${px},${py - 7}l7,7 -7,7 -7,-7Z`, ...attrs }));
      else g.append(svgNode('circle', { cx: px, cy: py, r: 6, ...attrs }));
      return g;
    };
    const description = [...Object.values(families).flatMap(f => f.rows.map(r => `${f.name}, ${r.chunk} ms: VoiceBench ${r.score}, FD-Score ${fdScore(r).toFixed(2)}`)), ...baselines.map(r => `${r.name}: VoiceBench ${r.score}, ${r.chunk} ms, FD-Score ${fdScore(r).toFixed(2)}`), ...hdModels.map(r => `${r.name}, half-duplex: VoiceBench ${r.score}`)].join('; ');
    svg.append(svgNode('title', { id: 'chart-title' }, `Full- and half-duplex model landscape: VoiceBench by ${isChunk ? 'chunk size' : 'FD-Score'}`));
    svg.append(svgNode('desc', { id: 'chart-description' }, description));
    svg.append(label('VoiceBench score ↑', 62, 24));
    svg.append(svgNode('rect', { x: 793, y: 43, width: 237, height: 357, rx: 6, fill: '#f7f9f6' }));
    svg.append(label('HALF-DUPLEX', 819, 28, '#63706b', { 'font-size': 11, 'letter-spacing': 1 }));
    [30, 40, 50, 60, 70, 80, 90].forEach(score => {
      svg.append(svgNode('line', { x1: 62, x2: 1020, y1: y(score), y2: y(score), stroke: '#e7ebe4' }));
      svg.append(label(String(score), 48, y(score) + 4, '#7a8780', { 'text-anchor': 'end', 'font-size': 12 }));
    });
    svg.append(svgNode('path', { d: 'M62,43V400H757 M796,400H1020', fill: 'none', stroke: '#8e9a94', 'stroke-width': 1.2 }));
    if (isChunk) {
      [0, 200, 400, 600, 800, 1000].forEach(chunk => svg.append(label(chunk.toLocaleString('en-US'), x({chunk}), 426, '#63706b', { 'text-anchor': 'middle', 'font-size': 12 })));
      svg.append(svgNode('path', { d: 'M765,405l9,-10 M778,405l9,-10', stroke: '#8e9a94', 'stroke-width': 1.5 }));
      svg.append(label('∞', 820, 427, '#63706b', { 'text-anchor': 'middle', 'font-size': 22 }));
    } else {
      [10,20,30,40,50,60,70,80].forEach(value => svg.append(label(String(value), 62 + (value - 10) / 70 * 702, 426, '#63706b', { 'text-anchor': 'middle', 'font-size': 12 })));
    }
    svg.append(label(isChunk ? 'Chunk size (ms)' : 'Interactivity (FD-Score) →', 402, 462, '#63706b', { 'text-anchor': 'middle' }));
    svg.append(label(isChunk ? 'Turn-based' : 'Score references', 904, 451, '#63706b', { 'text-anchor': 'middle', 'font-size': 12 }));
    hdModels.forEach(hd => {
      if (!isChunk) svg.append(svgNode('line', { x1: 62, x2: 811, y1: y(hd.score), y2: y(hd.score), stroke: hd.color, opacity: .35, 'stroke-dasharray': '5 5' }));
      const point = marker(820, y(hd.score), hd.shape, hd.color, true);
      point.append(svgNode('title', {}, `${hd.name}: ${hd.score} VoiceBench (half-duplex)`));
      svg.append(point, label(hd.name, 837, y(hd.score) - 7, hd.color), label(hd.score.toFixed(1), 837, y(hd.score) + 14, hd.color, { 'font-size': 12 }));
    });
    Object.values(families).forEach(f => {
      const last = f.rows[f.rows.length - 1];
      if (isChunk) svg.append(svgNode('line', { x1: x(last), y1: y(last.score), x2: 820, y2: y(f.backbone), stroke: f.color, opacity: .5, 'stroke-width': 2, 'stroke-dasharray': '6 7' }));
      svg.append(svgNode('polyline', { points: f.rows.map(r => `${x(r)},${y(r.score)}`).join(' '), fill: 'none', stroke: f.color, 'stroke-width': 3, 'stroke-linejoin': 'round' }));
      f.rows.forEach((r, i) => {
        const point = marker(x(r), y(r.score), f.shape, f.color, false, f === family && i === rowIndex);
        point.append(svgNode('title', {}, `${f.name} · ${r.chunk} ms · VoiceBench ${r.score} · FD-Score ${fdScore(r).toFixed(2)}`));
        svg.append(point);
        if (!isChunk) {
          const offsets = f === families.qwen ? [[24,-5], [4,23], [0,-15], [-4,24], [-19,-17]] : [[15,7], [-24,20], [1,-13], [-20,-16]];
          svg.append(label(`${r.chunk}`, x(r) + offsets[i][0], y(r.score) + offsets[i][1], f.color, { 'font-size': 11, 'text-anchor': 'middle' }));
        }
      });
      const labelPosition = isChunk ? (f === families.qwen ? [375,139] : [349,303]) : (f === families.qwen ? [403,121] : [250,283]);
      svg.append(label(f.name, ...labelPosition, f.color, { 'font-size': 17, 'font-weight': 550 }));
    });
    baselines.forEach(r => {
      const [lx, ly] = isChunk ? r.chunkLabel : r.fdLabel;
      const endX = Math.max(lx - 7, Math.min(x(r), lx + r.name.length * 7.7 + 5));
      svg.append(svgNode('line', { x1: x(r), y1: y(r.score), x2: endX, y2: ly + (y(r.score) > ly ? 5 : -15), stroke: r.color, opacity: .55 }));
      const point = marker(x(r), y(r.score), 'diamond', r.color);
      point.append(svgNode('title', {}, `${r.name} · ${r.chunk} ms · VoiceBench ${r.score} · FD-Score ${fdScore(r).toFixed(2)}`));
      svg.append(point, label(r.name, lx, ly, r.color));
    });
    $('landscape-note').textContent = isChunk
      ? 'Filled markers: full-duplex models. Open markers at ∞: half-duplex models operating by turns, not a measured infinite latency. Dashed links connect each D2 family to its original backbone. Chunk sizes describe interaction scheduling; VoiceBench values are from paper Table 2.'
      : 'FD-Score combines turn-taking and interruption success with their latencies (Appendix F); higher is better. Point labels give D2 chunk sizes in ms. Half-duplex models have no FD-Score and appear as horizontal VoiceBench references. Values: paper Tables 1–2.';
  }

  function renderResults() {
    const row = family.rows[rowIndex];
    const controls = $('chunk-options');
    controls.replaceChildren();
    family.rows.forEach((r, i) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = `${r.chunk.toLocaleString('en-US')} ms`;
      button.setAttribute('aria-pressed', String(i === rowIndex));
      button.addEventListener('click', () => {
        rowIndex = i;
        // Update in place to retain keyboard focus.
        controls.querySelectorAll('button').forEach((b, j) => b.setAttribute('aria-pressed', String(j === i)));
        renderSelection();
      });
      controls.append(button);
    });
    renderSelection();
  }
  function renderSelection() {
    const row = family.rows[rowIndex];
    const container = $('selected-results');
    container.replaceChildren();
    [['VoiceBench score', row.score.toFixed(1), '/ 100'], ['FD-Score', fdScore(row).toFixed(2), '/ 100'], ['Turn-taking latency', row.latency.toLocaleString('en-US'), 'ms'], ['Pause-handling success', row.pause.toFixed(1), '%']].forEach(([label, value, unit]) => {
      const dl = document.createElement('dl');
      dl.className = 'selected-result';
      const dt = document.createElement('dt'); dt.textContent = label;
      const dd = document.createElement('dd'); dd.textContent = value;
      const suffix = document.createElement('span'); suffix.textContent = unit;
      dd.append(suffix); dl.append(dt, dd); container.append(dl);
    });
    $('tradeoff-note').textContent = `At ${row.chunk.toLocaleString('en-US')} ms, ${family.name} scores ${row.score.toFixed(1)} on VoiceBench, with ${row.latency.toLocaleString('en-US')} ms turn-taking latency and ${row.pause.toFixed(1)}% pause-handling success.`;
    drawChart();
  }
  $('backbone').addEventListener('change', (event) => {
    family = families[event.target.value]; rowIndex = 0; renderResults();
  });
  $('chart-axis').addEventListener('change', (event) => { chartAxis = event.target.value; drawChart(); });
  [...baselines.map(r => ({...r, type: 'Full-duplex'})), ...hdModels.map(r => ({...r, type: 'Half-duplex'}))].forEach(r => {
    const tr = document.createElement('tr');
    [r.name, r.type, r.chunk ? `${r.chunk} ms` : 'Turn-based', r.score.toFixed(1), r.chunk ? fdScore(r).toFixed(2) : '—'].forEach((value, i) => {
      const cell = document.createElement(i ? 'td' : 'th');
      if (!i) cell.scope = 'row';
      cell.textContent = value; tr.append(cell);
    });
    $('comparison-table-body').append(tr);
  });
  renderResults();
})();
